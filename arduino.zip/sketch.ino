#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// LCD I2C (20x4)
LiquidCrystal_I2C lcd(0x27, 20, 4);

// Кнопка на пине 2
const int buttonPin = 2;

// Переменные для кнопки
int buttonState = 0;
int lastButtonState = 1;  // HIGH (не нажата)
unsigned long lastPressTime = 0;
const unsigned long debounceDelay = 50;

// Флаг для обработки
bool shouldGenerate = false;

// Результаты
int randomNumber;
unsigned long long fibonacciResult;
double elapsedTimeSec;

// Функция вывода 64-битных чисел
void printULL(unsigned long long value) {
  if (value == 0) {
    lcd.print('0');
    return;
  }
  
  char buffer[20];
  char *p = buffer + sizeof(buffer) - 1;
  *p = '\0';
  
  while (value > 0) {
    *(--p) = '0' + (value % 10);
    value /= 10;
  }
  
  lcd.print(p);
}

// Рекурсивный Фибоначчи
unsigned long long fibonacci(int n) {
  if (n == 0) return 0;
  if (n == 1) return 1;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

void setup() {
  lcd.init();
  lcd.backlight();
  pinMode(buttonPin, INPUT_PULLUP);
  randomSeed(analogRead(A0));
  
  lcd.clear();
  lcd.setCursor(2, 0);
  lcd.print("Fibonacci Test");
  lcd.setCursor(3, 1);
  lcd.print("Press Button");
  lcd.setCursor(0, 2);
  lcd.print("N: --");
  lcd.setCursor(0, 3);
  lcd.print("Time: --");
  
  delay(2000);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Ready!");
  lcd.setCursor(0, 1);
  lcd.print("Press button...");
}

void loop() {
  // Читаем состояние кнопки
  int reading = digitalRead(buttonPin);
  
  // Антидребезг
  if (reading != lastButtonState) {
    lastPressTime = millis();
  }
  
  if ((millis() - lastPressTime) > debounceDelay) {
    // Если состояние стабильно
    if (reading != buttonState) {
      buttonState = reading;
      
      // Если кнопка НАЖАТА (LOW, потому что INPUT_PULLUP)
      if (buttonState == LOW) {
        shouldGenerate = true;
      }
    }
  }
  
  lastButtonState = reading;
  
  // Генерация данных
  if (shouldGenerate) {
    shouldGenerate = false;
    
    // 1. Генерируем случайное число от 5 до 30
    randomNumber = random(5, 31);
    
    // 2. Замеряем время и вычисляем Фибоначчи
    unsigned long startMicros = micros();
    fibonacciResult = fibonacci(randomNumber);
    unsigned long endMicros = micros();
    
    elapsedTimeSec = (endMicros - startMicros) / 1000000.0;
    
    // 3. Выводим на LCD
    lcd.clear();
    
    // Строка 1: случайное число
    lcd.setCursor(0, 0);
    lcd.print("N: ");
    lcd.print(randomNumber);
    
    // Строка 2: время
    lcd.setCursor(0, 1);
    lcd.print("Time: ");
    lcd.print(elapsedTimeSec, 5);
    lcd.print(" sec.");
    
    // Строка 3: число Фибоначчи
    lcd.setCursor(0, 2);
    lcd.print("Fib: ");
    printULL(fibonacciResult);
    
    // Строка 4: подсказка
    lcd.setCursor(0, 3);
    lcd.print("Press again...");
  }
}